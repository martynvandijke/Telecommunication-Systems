# Telecommunication-Systems
Python script for the hamming code for the TU/e course Telecommunication Systems 
