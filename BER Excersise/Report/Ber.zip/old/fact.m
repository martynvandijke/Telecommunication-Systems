% function [ output_args ] = fact( input_args )
% %FACT Summary of this function goes here
% %   Detailed explanation goes here
% 
% 
% end

function f = fact(n)
f = prod(1:n);
disp('Ben hiero');
end

